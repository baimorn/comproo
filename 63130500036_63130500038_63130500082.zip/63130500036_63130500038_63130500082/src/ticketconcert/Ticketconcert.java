/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticketconcert;

import java.math.BigDecimal;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Ticketconcert {

    //class แรก เป็นการประกาศชื่อตัวแปรทั้งหมด
    private static final String[] seat = {"A1", "A2", "B1", "B2", "C1", "C2", "D1", "D2"}; //zone ที่นั่ง
    private static final String[] day = {"Saturday", "Sunday"}; //บอกวันที่จัดงาน
    private static final String[] time = {"12:00", "17:00"}; //บอกเวลของการจัดงาน
    private static final double[] price = {5000, 5000, 4000, 4000, 3000, 3000, 2000, 2000}; //บอกราคาของแต่ละบัตร
    private static int selectZone;
    private static String checkStatus = "";
    private boolean[] Ticket_Status;
    private int[] statusSeat = {10, 10, 10, 10, 10, 10, 10, 10}; //บอกจำนวนที่นั่งของแต่ละ zone
    public String customer;
    public Ticketconcert() {
    }

    public void chooseZone() {
//    Scanner zone = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        System.out.print("Choose Number of zone : ");
        selectZone = sc.nextInt() - 1;
        if (selectZone >= 0 && selectZone <= seat.length) {
            if (statusSeat[selectZone] > 0) {
                statusSeat[selectZone]--;
                addTicket(seat[selectZone], price[selectZone], dateAndTime());
//            getSeat(selectZone);
//            getPrice(selectZone);
            }
        } else {
            chooseZone();
        }
    }

    public String dateAndTime() {
        //Scanner dd = new Scanner(System.in);
        System.out.print("Choose Number of date and time : ");
        Scanner sc = new Scanner(System.in);
        switch (sc.nextInt()) {
            case 1:
                return day[0] + " " + time[0];
            case 2:
                return day[1] + " " + time[1];
        }
        return null;
    }

    public static String getSeatAndPrice() {
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < seat.length; i++) {
            str.append("ID: " + (i + 1) + " |Seat : " + seat[i] + "| Price : " + price[i] + "\n");
        }
        return str.toString();
    }

    public String getSeat(int number) {
        return seat[number-1];
    }

    public String getDay(int number) {
        return day[number-1];
    }

    public String getTime(int number) {
        return time[number-1];
    }

    public double getPrice(int number) {
        return price[number-1];
    }

    public static String getDayAndTime() {
        StringBuilder dt = new StringBuilder();
        for (int j = 0; j < day.length; j++) {
            dt.append("ID: " + (j + 1) + " |Day : " + day[j] + "| Time : " + time[j] + "\n");
        }
        return dt.toString();
    }

    public void addTicket(String seat, double price, String date) {
        if (seat != null && price != 0 && date != null) {
            checkStatus += "Zone : " + seat + ", Date&Time : " + date + ", Price : " + price + "\n";
            System.out.println("\nBuy Ticket Complete.");
        }
    }
    public String ticketStatus() {
        return checkStatus;
    }
}

/*public String day(int j){
        if(j>day.length-1||j<0){return "Don't have this day";}
        return day[j-1];
    }
    public String time(int k){
        if(k>time.length-1||k<0){return "Don't have this time";}
        return time[k-1];
    }
    public int price(int l){
        if(l>price.length-1||l<0){return 0;}
        return price[l-1];
    }
   
   public static String buyTicket(String accountName) {
        return accountName;
   }*/
//    public int statusseat(int m){
//        if(1>statusseat.length-1||m>=0){} else {
//            return 0;
//        }
//        return statusseat[m-1];
//    }
//    public boolean statusticket(){
//        return this.statusticket = statusticket ;
//    }
//    @Override
//    public String toString() {
//        return "Ticketconcert{" + "accoutname=" + accoutname + ", seat=" + seat + ", day=" + day + ", time=" + time + ", price=" + price + ", zone=" + statusseat + ", status=" + statusticket + ", sc=" + sc + '}';
//    }
//


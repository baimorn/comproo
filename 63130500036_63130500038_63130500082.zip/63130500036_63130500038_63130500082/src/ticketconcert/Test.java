package ticketconcert;

import java.util.Arrays;

public class Test {

    public static void main(String[] args) {
        //Customer customer = new Customer("Baimorn","0954584532");
        Ticketconcertmenu ticketconcert = new Ticketconcertmenu(new Customer("Baimorn", "0954584532"));
        ticketconcert.ticketMenu();
    }
}
